import pygame
from pygame import MOUSEBUTTONDOWN

from menu1 import Obj

class Menu:
    def __init__(self,imagem):

        self.bg = Obj(imagem, 0, 0)
        self.mudar_tela = False
        self.mn = False
        self.botoes = True
        self.exits = True
        self.bt_sr = False



        self.msx = 0
        self.msy = 0
        self.m_x1 = 526
        self.m_y1 = 517
        self.m_x2 = 724
        self.m_y2 = 577
        self.m_x12 = 856
        self.m_y12 = 512
        self.m_x22 = 1062
        self.m_y22 = 579

    def draw(self, tela):
        self.bg.grupo.draw(tela)

    def events(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self.mudar_tela = True
                self.botoes = False
                self.mn = False
                self.exits = True
        if event.type == MOUSEBUTTONDOWN:
            self.msx = pygame.mouse.get_pos()[0]
            self.msy = pygame.mouse.get_pos()[1]

            if self.msx > self.m_x1 and self.msy > self.m_y1 and self.msx < self.m_x2 and self.msy < self.m_y2:
                self.mudar_tela = True
                self.botoes = False
                self.mn = False
                self.exits = True

            #if self.msx > self.m_x12 and self.msy > self.m_y12 and self.msx < self.m_x22 and self.msy < self.m_y22:
               #self.bt_sr = True
class Manual(Menu):
    def __init__(self, imagem):
        super().__init__(imagem)

class Perda(Menu):

    def __init__(self, imagem):
        super().__init__(imagem)

