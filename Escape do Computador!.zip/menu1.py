import pygame

class Obj:
    def __init__(self, image, x, y):

        self.grupo = pygame.sprite.Group()
        self.sprite = pygame.sprite.Sprite(self.grupo)

        self.sprite.image = pygame.image.load(image)
        self.sprite.rect = self.sprite.image.get_rect()
        self.sprite.rect[0]= x
        self.sprite.rect[1]= y

        self.frame = 1

        self.time = 0

    def drawing(self, tela):
        self.grupo.draw(tela)

    def anime(self, image, time, frames):

        self.time += 1
        if self.time == time:
            self.time = 0
            self.frame += 1

        if self.frame == frames:
            self.frame = 1

        self.sprite.image = pygame.image.load("assets/" + image + str(self.frame) + ".png")


class Bee(Obj):

    def __init__(self, image, x, y):
        super().__init__(image, x, y)

        pygame.mixer.init()
        self.sounds_pts = pygame.mixer.Sound("sounds/score.ogg")
        self.sounds_bateu = pygame.mixer.Sound("sounds/bateu.ogg")


        self.vida = 3
        self.pts = 0

    def muv_bee(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.sprite.rect[0] = pygame.mouse.get_pos()[0] - 35
            self.sprite.rect[1] = pygame.mouse.get_pos()[1] - 30
        if self.sprite.rect[0] <= 20:
            self.sprite.rect[0] = 20
        if self.sprite.rect[0] >= 1330:
            self.sprite.rect[0] = 1330
        if self.sprite.rect[1] <= 50:
            self.sprite.rect[1] = 50
        if self.sprite.rect[1] >= 600:
            self.sprite.rect[1] = 600


    def colisao(self, group, name):

        name = name
        colisao = pygame.sprite.spritecollide(self.sprite, group, True)
        if name == "Flower" and colisao:
            self.pts +=1
            self.sounds_pts.play()

        elif name == "Spider" and colisao:
            self.vida -= 1
            self.sounds_bateu.play()



class Texto:

    def __init__(self,size,texto):
        pygame.font.init()
        self.font = pygame.font.SysFont("assets/desktop.ini", size)
        self.render = self.font.render(texto, True, (244,191,191))

    def draw(self, tela, x, y):

        tela.blit(self.render, (x,y))

    def update_text(self,texto):

        self.render = self.font.render(texto, True, (244, 191, 191))


