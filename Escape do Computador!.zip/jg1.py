from menu1 import Obj, Bee, Texto
import random
from menu import Botao
import pygame


class Game:
    def __init__(self):
        self.bg = Obj("assets/bg2.png", 0,0)
        self.bg2 = Obj("assets/bg2.png", 0, -800)
        self.mudar_tela = False

        self.virus = Obj("assets/vírus1.png", random.randrange(0,300), -50)
        self.virus2 = Obj("assets/vírus1.png", random.randrange(0, 300), -50)
        self.flor1 = Obj("assets/mouse ppa1.png", random.randrange(0,300), -50)
        self.flor2 = Obj("assets/ram1.png", random.randrange(0, 300), -50)
        self.flor3 = Obj("assets/webcam1.png", random.randrange(0, 300), -50)
        self.flor4 = Obj("assets/cpu1.png", random.randrange(0, 300), -50)
        self.bee = Bee("assets/computador1.png", 150, 600)
        self.mudar_cena = False

        self.score1 = Texto(40,"Pontos:")
        self.vida = Texto(40, "Vidas:")
        self.score = Texto(40,"0")
        self.lifes = Texto(40, "3")

        pygame.font.init()
        self.fonte = pygame.font.SysFont('assets/desktop.ini', 40, bold=False, italic=True)
        self.pontos = self.bee.pts
        self.msg = f'Pontos: {self.pontos}'
        self.text = self.fonte.render(self.msg, True, (244, 191, 191))

    def draw(self, tela):
        self.bg.drawing(tela)
        self.bg2.drawing(tela)
        self.virus.drawing(tela)
        self.virus2.drawing(tela)
        self.flor1.drawing(tela)
        self.flor2.drawing(tela)
        self.flor3.drawing(tela)
        self.flor4.drawing(tela)
        self.bee.drawing(tela)
        self.score1.draw(tela, 270,20)
        self.vida.draw(tela, 55,20)
        self.score.draw(tela, 380, 20)
        self.lifes.draw(tela, 145, 20)

    def update(self):
        self.muv_bg()
        self.virus.anime("vírus", 8, 3)
        self.virus2.anime("vírus", 8, 3)
        self.flor1.anime("mouse ppa", 8, 2)
        self.flor2.anime("ram", 8, 2)
        self.flor3.anime("webcam", 8, 2)
        self.flor4.anime("cpu", 8, 2)
        self.muv_virus()
        self.muv_virus2()
        self.muv_ram()
        self.muv_cpu()
        self.muv_webcam()
        self.muv_mouse()
        self.bee.anime("computador", 0.5, 2)
        self.bee.colisao(self.virus.grupo, "Spider")
        self.bee.colisao(self.virus2.grupo, "Spider")
        self.bee.colisao(self.flor1.grupo, "Flower")
        self.bee.colisao(self.flor2.grupo, "Flower")
        self.bee.colisao(self.flor3.grupo, "Flower")
        self.bee.colisao(self.flor4.grupo, "Flower")
        self.perda()
        self.score.update_text(str(self.bee.pts))
        self.lifes.update_text(str(self.bee.vida))



    def muv_bg(self):
        self.bg.sprite.rect[1] += 5

        self.bg2.sprite.rect[1] += 5

        if self.bg.sprite.rect[1] >= 800:
            self.bg.sprite.rect[1] = 0

        if self.bg2.sprite.rect[1] >= 0:
            self.bg2.sprite.rect[1] = -800

    def muv_virus(self):
        self.virus.sprite.rect[1] += 12

        if self.virus.sprite.rect[1] >= 800:
            self.virus.sprite.kill()
            self.virus = Obj("assets/vírus1.png", random.randrange(0,1535), -50)

    def muv_virus2(self):
        self.virus2.sprite.rect[1] += 15

        if self.virus2.sprite.rect[1] >= 700:
            self.virus2.sprite.kill()
            self.virus2 = Obj("assets/vírus1.png", random.randrange(0, 1535), -50)

    def muv_mouse(self):
        self.flor1.sprite.rect[1] += 15

        if self.flor1.sprite.rect[1] >= 720:
            self.flor1.sprite.kill()
            self.flor1 = Obj("assets/mouse ppa1.png", random.randrange(0, 1535), -50)

    def muv_ram(self):
        self.flor2.sprite.rect[1] += 14

        if self.flor2.sprite.rect[1] >= 740:
            self.flor2.sprite.kill()
            self.flor2 = Obj("assets/ram1.png", random.randrange(0, 1535), -50)

    def muv_webcam(self):
        self.flor3.sprite.rect[1] += 16

        if self.flor3.sprite.rect[1] >= 760:
            self.flor3.sprite.kill()
            self.flor3 = Obj("assets/webcam1.png", random.randrange(0, 1535), -50)
    def muv_cpu(self):
        self.flor4.sprite.rect[1] += 18

        if self.flor4.sprite.rect[1] >= 710:
            self.flor4.sprite.kill()
            self.flor4 = Obj("assets/cpu1.png", random.randrange(0, 1535), -50)

    def perda(self):
        if self.bee.vida <= 0:
            self.mudar_cena = True



