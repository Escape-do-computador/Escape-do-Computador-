import pygame

class C1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.pg1 = pygame.image.load("personagens2/cachorrinho.png")
        self.pg1_1 = []

        for i in range(0,9):
            self.img = self.pg1.subsurface((i* 64,0),(64,64))
            self.img = pygame.transform.scale(self.img, (64* 2.5, 64* 2.5))
            self.pg1_1.append(self.img)

        self.index = 0
        self.image= self.pg1_1[self.index]
        self.rect= self.image.get_rect()
        self.rect.center= (1400, 660)

    def update(self):
        if self.index > 8:
            self.index = 0
        self.index += 0.30
        self.image = self.pg1_1[int(self.index)]


class C2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.pg2 = pygame.image.load("personagens2/coelhino.png")
        self.pg2_1 = []

        for i in range(0,9):
            self.img2 = self.pg2.subsurface((i* 64,0),(64,64))
            self.img2 = pygame.transform.scale(self.img2, (64* 2 , 64* 2))
            self.pg2_1.append(self.img2)

        self.index2 = 0
        self.image = self.pg2_1[self.index2]
        self.rect = self.image.get_rect()
        self.rect.center= (1400, 670)

    def update(self):
        if self.index2 > 8:
            self.index2 = 0
        self.index2 += 0.30
        self.image = self.pg2_1[int(self.index2)]


class C3(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.pg3 = pygame.image.load("personagens2/foquinha.png")
        self.pg3_1 = []

        for i in range(0,9):
            self.img3 = self.pg3.subsurface((i* 64,0),(64,64))
            self.img3 = pygame.transform.scale(self.img3, (64* 2.5 ,64* 2.5))
            self.pg3_1.append(self.img3)

        self.index3 = 0
        self.image = self.pg3_1[self.index3]
        self.rect = self.image.get_rect()
        self.rect.center= (1350, 660)

    def update(self):
        if self.index3 > 8:
            self.index3 = 0
        self.index3 += 0.30
        self.image = self.pg3_1[int(self.index3)]


class C4(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.pg4 = pygame.image.load("personagens2/girafinha.png")
        self.pg4_1 = []

        for i in range(0,9):
            self.img4 = self.pg4.subsurface((i* 64,0),(64,64))
            self.img4 = pygame.transform.scale(self.img4, (64* 2.3, 64* 2.3))
            self.pg4_1.append(self.img4)

        self.index4 = 0
        self.image= self.pg4_1[self.index4]
        self.rect= self.image.get_rect()
        self.rect.center= (1370, 650)

    def update(self):
        if self.index4 > 8:
            self.index4 = 0
        self.index4 += 0.30
        self.image = self.pg4_1[int(self.index4)]

