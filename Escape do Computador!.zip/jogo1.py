import pygame
from pygame import MOUSEBUTTONDOWN

from mn1 import Menu, Perda, Manual
from jg1 import Game
from menu import Botao

class Abelha:

    def __init__(self, titulo, x, y):

        pygame.mixer.init()
        pygame.mixer.music.load("sounds/bg.ogg")
        pygame.mixer.music.play(-1)

        self.msx = 0
        self.msy = 0
        self.m_x1 = 526
        self.m_y1 = 517
        self.m_x2 = 724
        self.m_y2 = 577
        self.m_x12 = 856
        self.m_y12 = 512
        self.m_x22 = 1062
        self.m_y22 = 579

        self.tela = pygame.display.set_mode([x,y])
        self.titulo = pygame.display.set_caption(titulo)
        self.menu = Menu("tela/tmljg1.png")
        self.bt = pygame.image.load("tela/bt11.png")
        self.bt1 = Botao(669, 420, self.bt, 1)
        self.sair = pygame.image.load("tela/bt12.png")
        self.s = Botao(668,513,self.sair,1)

        pygame.mixer.init()
        self.click = pygame.mixer.Sound("sounds/click.wav")

        self.gameover = Perda("assets/gameover.png")
        self.game = Game()

        self.over = False
        self.inicio = True
        self.menu.bt_sr = False

        self.continua = True

        self.fps = pygame.time.Clock()
        self.bt_sr = False

        self.mudar_manual = False
    def draw(self):
        self.tela.fill([0,0,0])

        if not self.menu.mudar_tela:
            self.menu.draw(self.tela)
            self.bt1.draw(self.tela)
            self.s.draw(self.tela)
            self.botoes = True
            self.inicio = True

        elif not self.game.mudar_cena:
            self.game.draw(self.tela)
            self.game.update()
            self.botoes = False
            self.over = False
            self.inicio = False

        elif not self.gameover.mudar_tela:
            self.gameover.draw(self.tela)
            #self.game.score.draw(self.tela,310,150)
            #self.game.score1.draw(self.tela, 200, 150)

            #self.tela.blit(self.game.text,(135,200))
            self.over = True

        else:
            self.menu.mudar_tela = False
            self.game.mudar_cena = False
            self.gameover.mudar_tela = False
            self.game.bee.vida = 3
            self.game.bee.pts = 0

    def events(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.continua = False
                pygame.mixer.music.stop()
            if not self.menu.mudar_tela:
                self.menu.events(event)
            elif not self.game.mudar_cena:
                self.game.bee.muv_bee(event)

            else:

                self.gameover.events(event)
                pygame.mixer_music.stop()

                if event.type == MOUSEBUTTONDOWN:
                    self.msx = pygame.mouse.get_pos()[0]
                    self.msy = pygame.mouse.get_pos()[1]

                    if self.msx > self.m_x1 and self.msy > self.m_y1 and self.msx < self.m_x2 and self.msy < self.m_y2:
                        self.click.play()
                        self.mudar_tela = True
                        self.botoes = False
                        self.mn = False
                        self.exits = True
                        pygame.mixer_music.play(-1)

                    if self.msx > self.m_x12 and self.msy > self.m_y12 and self.msx < self.m_x22 and self.msy < self.m_y22:
                        self.click.play()
                        self.continua = False

            if self.botoes:
                if self.bt1.draw(self.tela):
                    self.click.play()
                    self.menu.mudar_tela = True
                if self.s.draw(self.tela):
                    self.click.play()
                    self.continua = False
                    pygame.mixer.music.stop()

    def update(self):
        while self.continua:
            self.fps.tick(30)
            self.draw()
            self.events()
            pygame.display.update()