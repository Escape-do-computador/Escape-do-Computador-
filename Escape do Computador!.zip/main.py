from pygame import MOUSEBUTTONDOWN

from menu import Botao
from pg3 import*
from pg2 import*
from pg import*
from jogo1 import Abelha

tela = pygame.display.set_mode((1540, 800))
pygame.display.set_caption("Escape do computador!")


sprites = pygame.sprite.Group()

rcrr = U()

rcoe = D()

rg = T()

rf = Q()

sprites.add(rcrr,rcoe,rg,rf)

p11 = pygame.sprite.Group()
p12 = pygame.sprite.Group()
p13 = pygame.sprite.Group()
p14 = pygame.sprite.Group()
usuario = pygame.sprite.Group()

p1 = P1()
p2 = P2()
p3 = P3()
p4 = P4()

p11.add(p1)
p12.add(p2)
p13.add(p3)
p14.add(p4)

c11 = pygame.sprite.Group()
c12 = pygame.sprite.Group()
c13 = pygame.sprite.Group()
c14 = pygame.sprite.Group()

c1 = C1()
c2 = C2()
c3 = C3()
c4 = C4()

c11.add(c1)
c12.add(c2)
c13.add(c3)
c14.add(c4)

teladepg = pygame.image.load("tela/1.png")

relogio = pygame.time.Clock()

#telas

manual = pygame.image.load("tela/manual.png")

tela1 = pygame.image.load("tela/1.png")
tela2 = pygame.image.load("tela/2.png")
tela3 = pygame.image.load("tela/3.png")
tela4 = pygame.image.load("tela/4.png")
tela5 = pygame.image.load("tela/7.png")
tela6 = pygame.image.load("tela/5.png")
tela7 = pygame.image.load("tela/8.png")
tela8 = pygame.image.load("tela/6.png")
tela9 = pygame.image.load("tela/fn1.png")
tela10 = pygame.image.load("tela/fn2.png")
tela11 = pygame.image.load("tela/fn3.png")
tela12 = pygame.image.load("tela/agradecimentos.png")

#perguntas
pg1 = pygame.image.load("tela/10.png")
pg2 = pygame.image.load("tela/11.png")
pg3 = pygame.image.load("tela/12.png")
pg4 = pygame.image.load("tela/13.png")
pg5 = pygame.image.load("tela/14.png")
pg6 = pygame.image.load("tela/15.png")
pg7 = pygame.image.load("tela/16.png")
pg8 = pygame.image.load("tela/17.png")
pg9 = pygame.image.load("tela/18.png")
pg10 = pygame.image.load("tela/19.png")
pg11 = pygame.image.load("tela/20.png")
pg12 = pygame.image.load("tela/21.png")
pg13 = pygame.image.load("tela/22.png")
pg14 = pygame.image.load("tela/23.png")
pg15 = pygame.image.load("tela/24.png")
pg16 = pygame.image.load("tela/25.png")
pg17 = pygame.image.load("tela/26.png")
pg18 = pygame.image.load("tela/27.png")
pg19 = pygame.image.load("tela/28.png")
pg20 = pygame.image.load("tela/29.png")
pg21 = pygame.image.load("tela/30.png")
pg22 = pygame.image.load("tela/31.png")
pg23 = pygame.image.load("tela/32.png")
pg24 = pygame.image.load("tela/33.png")
pg25 = pygame.image.load("tela/34.png")
pg26 = pygame.image.load("tela/35.png")
pg27 = pygame.image.load("tela/36.png")
pg28 = pygame.image.load("tela/37.png")
pg29 = pygame.image.load("tela/38.png")
pg30 = pygame.image.load("tela/39.png")


#erros
erro = pygame.image.load("tela/erro.png")
erro2 = pygame.image.load("tela/erro2.png")
erro3 = pygame.image.load("tela/erro3.png")
erro4 = pygame.image.load("tela/erro4.png")
erro5 = pygame.image.load("tela/erro5.png")
erro6 = pygame.image.load("tela/erro6.png")
erro7 = pygame.image.load("tela/erro7.png")
erro8 = pygame.image.load("tela/erro8.png")
erro9 = pygame.image.load("tela/erro9.png")
erro10 = pygame.image.load("tela/erro10.png")
erro11 = pygame.image.load("tela/erro11.png")
erro12 = pygame.image.load("tela/erro12.png")
erro13 = pygame.image.load("tela/erro13.png")
erro14 = pygame.image.load("tela/erro14.png")
erro15 = pygame.image.load("tela/erro15.png")
erro16 = pygame.image.load("tela/erro16.png")
erro17 = pygame.image.load("tela/erro17.png")
erro18 = pygame.image.load("tela/erro18.png")
erro19 = pygame.image.load("tela/erro19.png")
erro20 = pygame.image.load("tela/erro20.png")
erro21 = pygame.image.load("tela/erro21.png")
erro22 = pygame.image.load("tela/erro22.png")
erro23 = pygame.image.load("tela/erro23.png")
erro24 = pygame.image.load("tela/erro24.png")
erro25 = pygame.image.load("tela/erro25.png")
erro26 = pygame.image.load("tela/erro26.png")
erro27 = pygame.image.load("tela/erro27.png")
erro28 = pygame.image.load("tela/erro28.png")
erro29 = pygame.image.load("tela/erro29.png")
erro30 = pygame.image.load("tela/erro30.png")

#sons
pygame.mixer.init()
acerto_sound = pygame.mixer.Sound("sounds/acerto.wav")
erro_sound = pygame.mixer.Sound("sounds/erro.mp3")
tela_acerto = pygame.mixer.Sound("sounds/acerto final.mp3")
click = pygame.mixer.Sound("sounds/click.wav")


bfechar = pygame.image.load("tela/x2.png")
bf = Botao(800,216,bfechar,1)
bok = pygame.image.load("tela/ok2.png")
bk = Botao(490,477,bok,1)

bt1 = pygame.image.load("tela/bt1.png")
btt1 = Botao(977,375,bt1,1)
bt2 = pygame.image.load("tela/bt3.png")
btt2 = Botao(972,473,bt2,1)
bt3 = pygame.image.load("tela/bt2.png")
btt3 = Botao(975,563,bt3,1)



botoes = True

rect = erro.get_rect()
rect.center = tela.get_rect().center

mouse_x = 0
mouse_y = 0

# jogo

jx1 = 1313
jy1 = 114
jx2 = 1415
jy2 = 167

# seta 1

xst1 = 101
yst1 = 662
xst12 = 277
yst12 = 683

# seta 2

xst2 = 1218
yst2 = 659
xst22 = 1434
yst22 = 687

# nada

xn1 = 239
yn1 = 437
xn12 = 361
yn12 = 631

# ndog

xn2 = 519
yn2 = 443
xn22 = 671
yn22 = 631

# nfoc

xn3 = 821
yn3 = 443
xn32 = 967
yn32 = 631

# ngi

xn4 = 1105
yn4 = 425
xn42 = 1277
yn42 = 631

# a da 1

uxa = 193
uya = 439
uxa2 = 436
uya2 = 472

# b da 1

uxb = 193
uyb = 549
uxb2 = 491
uyb2 = 587

# c da 1

uxc = 901
uyc = 403
uxc2 = 1175
uyc2 = 463

# d da 1

uxd = 893
uyd = 505
uxd2 = 1263
uyd2 = 581

# erro

x1 = 819
y1 = 449
x2 = 835
y2 = 863

# a da 2

dxa = 191
dya = 439
dxa2 = 464
dya2 = 478

# b da 2

dxb = 189
dyb = 550
dxb2 = 397
dyb2 = 594

# c da 2

dxc = 894
dyc = 439
dxc2 = 1106
dyc2 = 480

# d da 2

dxd = 892
dyd = 556
dxd2 = 1146
dyd2 = 590

# a da 3

txa = 189
tya = 440
txa2 = 424
tya2 = 473

# b da 3

txb = 190
tyb = 553
txb2 = 423
tyb2 = 585

# c da 3

txc = 897
tyc = 437
txc2 = 1111
tyc2 = 475

# d da 3

txd = 898
tyd = 549
txd2 = 1131
tyd2 = 590

# a da 4
qxa = 185
qya = 428
qxa2 = 496
qya2 = 495

# b da 4
qxb = 187
qyb = 539
qxb2 = 482
qyb2 = 608

# c da 4
qxc = 885
qyc = 428
qxc2 = 1035
qyc2 = 4960

# d da 4
qxd = 890
qyd = 541
qxd2 = 1195
qyd2 = 609

# a da 5
cxa = 163
cya = 427
cxa2 = 416
cya2 = 492

# b da 5
cxb = 162
cyb =540
cxb2 = 698
cyb2 = 606

# c da 5
cxc = 874
cyc =428
cxc2 =1166
cyc2 =494

# d da 5
cxd =876
cyd =542
cxd2 =1374
cyd2 =606

# a da 6
sxa = 187
sya = 428
sxa2 = 562
sya2 = 491

# b da 6
sxb = 186
syb = 540
sxb2 = 471
syb2 = 607

# c da 6
sxc = 892
syc = 424
sxc2 = 1229
syc2 = 495

# d da 6
sxd = 893
syd = 537
sxd2 = 1165
syd2 = 608

# a da 7
sexa = 184
seya = 427
sexa2 = 342
seya2 = 494

# b da 7
sexb = 187
seyb = 541
sexb2 = 342
seyb2 = 604

# c da 7
sexc = 890
seyc = 427
sexc2 = 1049
seyc2 = 495

# d da 7
sexd = 895
seyd = 539
sexd2 = 1051
seyd2 = 608

# a da 8
oxa = 182
oya = 427
oxa2 = 369
oya2 = 493

# b da 8
oxb = 184
oyb = 541
oxb2 = 442
oyb2 = 607

# c da 8
oxc = 893
oyc = 425
oxc2 = 1080
oyc2 = 494

# d da 8
oxd = 893
oyd = 538
oxd2 = 1017
oyd2 = 610

# a da 9
nxa = 187
nya = 426
nxa2 = 481
nya2 = 494

# b da 9
nxb = 188
nyb = 542
nxb2 = 496
nyb2 = 607

# c da 9
nxc = 894
nyc = 427
nxc2 = 1344
nyc2 = 494

# d da 9
nxd = 895
nyd = 539
nxd2 = 1177
nyd2 = 609

# a da 10
dexa = 163
deya = 431
dexa2 = 610
deya2 = 496

# b da 10
dexb = 174
deyb = 541
dexb2 = 632
deyb2= 608

# c da 10
dexc = 873
deyc = 426
dexc2 = 1295
deyc2= 492

# d da 10
dexd = 891
deyd = 543
dexd2 = 1188
deyd2= 609

# a da 11
onxa = 172
onya = 429
onxa2 = 500
onya2 = 492

# b da 11
onxb = 172
onyb = 541
onxb2 = 521
onyb2 = 608

# c da 11
onxc = 881
onyc = 426
onxc2 = 1279
onyc2 = 494

# d da 11
onxd = 887
onyd = 538
onxd2 = 1384
onyd2 = 624

# a da 12
dozxa = 179
dozya = 426
dozxa2 = 624
dozya2 = 497

# b da 12
dozxb = 167
dozyb = 541
dozxb2 = 461
dozyb2 = 613

# c da 12
dozxc = 883
dozyc = 428
dozxc2 = 1086
dozyc2 = 505

# d da 12
dozxd = 876
dozyd = 540
dozxd2 = 1097
dozyd2 = 608

# a da 13
trxa = 186
trya = 325
trxa2 = 1444
trya2 = 411

# b da 13
trxb = 179
tryb = 433
trxb2 = 1438
tryb2 = 517

# c da 13
trxc = 182
tryc = 533
trxc2 = 1385
tryc2 = 638

# a da 14
quatxa = 172
quatya = 424
quatxa2 = 768
quatya2 = 535

# b da 14
quatxb = 173
quatyb = 547
quatxb2 = 1262
quatyb2 = 612

# c da 14
quatxc = 872
quatyc = 425
quatxc2 = 1407
quatyc2 = 509

# a da 15
quinxa = 106
quinya = 429
quinxa2 = 704
quinya2 = 507

# b da 15
quinxb = 105
quinyb = 542
quinxb2 =703
quinyb2 =621

# c da 15
quinxc =810
quinyc =427
quinxc2 =1361
quinyc2 =508

# d da 15
quinxd =812
quinyd =542
quinxd2 =1308
quinyd2 =616

# a da 16
dezxa = 133
dezya =375
dezxa2 =761
dezya2 =481

# b da 16
dezxb = 133
dezyb =489
dezxb2 =764
dezyb2 =636

# c da 16
dezxc =810
dezyc =376
dezxc2 =1421
dezyc2 =481

# d da 16
dezxd =813
dezyd =489
dezxd2 =1359
dezyd2 =631

# a da 17
dezexa = 162
dezeya = 379
dezexa2 = 534
dezeya2 = 447

# b da 17
dezexb = 161
dezeyb = 518
dezexb2 = 586
dezeyb2 = 583

# c da 17
dezexc = 834
dezeyc = 378
dezexc2 = 1185
dezeyc2 = 449

# d da 17
dezexd = 832
dezeyd = 516
dezexd2 = 1292
dezeyd2 = 583

# a da 18
dezoxa =159
dezoya =432
dezoxa2 =359
dezoya2 =499

# b da 18
dezoxb =179
dezoyb =540
dezoxb2 =454
dezoyb2 =610

# c da 18
dezoxc = 894
dezoyc = 427
dezoxc2 = 1085
dezoyc2 = 496

# d da 18
dezoxd =876
dezoyd =542
dezoxd2 =1087
dezoyd2 =612

# a da 19
dezenxa =179
dezenya =424
dezenxa2 =686
dezenya2 =501

# b da 19
dezenxb = 182
dezenyb = 541
dezenxb2= 625
dezenyb2 = 606

# c da 19
dezenxc = 891
dezenyc = 426
dezenxc2 = 1326
dezenyc2 = 513

# d da 19
dezenxd = 895
dezenyd = 543
dezenxd2 = 1305
dezenyd2 = 631

# a da 20
vxa = 172
vya = 415
vxa2 = 577
vya2 = 479

# b da 20
vxb = 178
vyb = 531
vxb2 = 651
vyb2 = 600

# c da 20
vxc = 830
vyc = 414
vxc2 = 1406
vyc2 = 480

# d da 20
vxd = 831
vyd = 527
vxd2 = 1288
vyd2 = 605

# a da 21
vuxa= 163
vuya= 427
vuxa2= 417
vuya2 = 507

# b da 21
vuxb= 169
vuyb= 541
vuxb2= 413
vuyb2 = 609

# c da 21
vuxc= 877
vuyc= 425
vuxc2= 1079
vuyc2 = 509

# d da 21
vuxd= 879
vuyd= 542
vuxd2= 1113
vuyd2 = 604

# a da 22
vdxa = 116
vdya = 426
vdxa2 = 399
vdya2 = 499

# b da 22
vdxb = 176
vdyb = 543
vdxb2 = 427
vdyb2 = 611

# c da 22
vdxc = 884
vdyc = 431
vdxc2 = 1117
vdyc2 = 505

# d da 22
vdxd = 877
vdyd = 537
vdxd2 = 1232
vdyd2 = 616

# a da 23
vtxa = 178
vtya = 421
vtxa2 = 492
vtya2 = 499

# b da 23
vtxb = 172
vtyb = 534
vtxb2 = 426
vtyb2 = 618

# c da 23
vtxc = 891
vtyc = 484
vtxc2 =1186
vtyc2 = 511

# d da 23
vtxd = 892
vtyd = 539
vtxd2 = 1178
vtyd2 = 619

# a da 24
vqxa = 182
vqya = 427
vqxa2 = 456
vqya2 = 512

# b da 24
vqxb = 168
vqyb = 543
vqxb2 = 443
vqyb2 = 615

# c da 24
vqxc =894
vqyc = 421
vqxc2 = 1246
vqyc2 = 502

# d da 24
vqxd =887
vqyd = 540
vqxd2 = 1168
vqyd2 = 607

# a da 25
vcxa = 186
vcya = 431
vcxa2 = 365
vcya2 = 498

# b da 25
vcxb =175
vcyb = 543
vcxb2 = 340
vcyb2 = 611

# c da 25
vcxc =888
vcyc = 424
vcxc2 = 1098
vcyc2 = 499

# d da 25
vcxd =890
vcyd = 540
vcxd2 = 1169
vcyd2 = 611

# a da 26
vsxa = 179
vsya = 427
vsxa2 = 416
vsya2 = 494

# b da 26
vsxb = 175
vsyb = 543
vsxb2 = 475
vsyb2 = 616

# c da 26
vsxc = 883
vsyc = 431
vsxc2 = 1109
vsyc2 = 467

# d da 26
vsxd = 893
vsyd = 541
vsxd2 = 1093
vsyd2 = 612

#a da 27
vsexa = 174
vseya = 399
vsexa2 = 840
vseya2 = 469

#b da 27
vsexb = 178
vseyb = 541
vsexb2 = 740
vseyb2 = 605

#c da 27
vsexc = 884
vseyc = 407
vsexc2 = 1297
vseyc2 = 484

#d da 27
vsexd = 891
vseyd = 539
vsexd2 = 1335
vseyd2 = 629

#a da 28
voxa = 186
voya = 411
voxa2 = 426
voya2 = 481

#b da 28
voxb = 187
voyb = 536
voxb2 = 424
voyb2 = 605

#c da 28
voxc = 848
voyc = 414
voxc2 = 1087
voyc2 = 481

#d da 28
voxd = 856
voyd = 538
voxd2 = 1111
voyd2 = 609

#a da 29
vnxa = 152
vnya = 415
vnxa2 = 643
vnya2 = 484

#b da 29
vnxb = 152
vnyb = 537
vnxb2 = 727
vnyb2 = 604

#c da 29
vnxc = 841
vnyc = 413
vnxc2 = 1315
vnyc2 = 490

#d da 29
vnxd = 845
vnyd = 530
vnxd2 = 1288
vnyd2 = 605

#a da 30
trixa = 150
triya = 426
trixa2 = 506
triya2 = 492

#b da 30
trixb = 149
triyb = 537
trixb2 =749
triyb2 =614

#c da 30
trixc =805
triyc =426
trixc2 =1283
triyc2 =507

#d da 30
trixd =809
triyd =541
trixd2 =1349
triyd2 =648

# b1 da fn1
x1fn1 = 690
y1fn1 = 495
x2fn1 = 855
y2fn1 = 565

#b2 da fn1
x1fn2 = 688
y1fn2 = 577
x2fn2 = 852
y2fn2 = 644


continua = True
er1 = False
er2 = False
er3 = False
er4 = False
er5 = False
er6 = False
er7 = False
er8 = False
er9 = False
er10 = False
er11 = False
er12 = False
er13 = False
er14 = False
er15 = False
er16 = False
er17 = False
er18 = False
er19 = False
er20 = False
er21 = False
er22 = False
er23 = False
er24 = False
er25 = False
er26 = False
er27 = False
er28 = False
er29 = False
er30 = False

pontos= 0
pygame.font.init()
fonte= pygame.font.SysFont('assets/desktop.ini',40,bold= False, italic= True)

#erros
while continua:

    mensagem = f'Pontos: {pontos}'
    texto = fonte.render(mensagem, True, (244, 191, 191))

    relogio.tick(30)
    tela.blit(teladepg, (0, 0))

    if er1 == True:

        tela.blit(erro, (200, 200))
        if bf.draw(tela):
            click.play()
            er1 = False
            teladepg = pg2

    elif er2 == True:

        if teladepg == pg2:
            tela.blit(erro2, (200,200))
            if bf.draw(tela):
                click.play()
                er2 = False
                teladepg = pg3

    elif er3 == True:

        if teladepg == pg3:
            tela.blit(erro3, (200,200))
            if bf.draw(tela):
                click.play()
                er3 = False
                teladepg = pg4

    elif er4 == True:

        if teladepg == pg4:
            tela.blit(erro4, (200,200))
            if bf.draw(tela):
                click.play()
                er4 = False
                teladepg = pg5

    elif er5 == True:

        if teladepg == pg5:
            tela.blit(erro5, (200,200))
            if bf.draw(tela):
                click.play()
                er5 = False
                teladepg = pg6

    elif er6 == True:

        if teladepg == pg6:
            tela.blit(erro6, (200,200))
            if bf.draw(tela):
                click.play()
                er6 = False
                teladepg = pg7

    elif er7 == True:

        if teladepg == pg7:
            tela.blit(erro7, (200,200))
            if bf.draw(tela):
                click.play()
                er7 = False
                teladepg = pg8

    elif er8 == True:

        if teladepg == pg8:
            tela.blit(erro8, (200,200))
            if bf.draw(tela):
                click.play()
                er8 = False
                teladepg = pg9

    elif er9 == True:

        if teladepg == pg9:
            tela.blit(erro9, (200,200))
            if bf.draw(tela):
                click.play()
                er9 = False
                teladepg = pg10

    elif er10 == True:

        if teladepg == pg10:
            tela.blit(erro10, (200,200))
            if bf.draw(tela):
                click.play()
                er10 = False
                teladepg = pg11

    elif er11 == True:

        if teladepg == pg11:
            tela.blit(erro11, (200,200))
            if bf.draw(tela):
                click.play()
                er11 = False
                teladepg = pg12

    elif er12 == True:

        if teladepg == pg12:
            tela.blit(erro12, (200,200))
            if bf.draw(tela):
                click.play()
                er12 = False
                teladepg = pg13

    elif er13 == True:

        if teladepg == pg13:
            tela.blit(erro13, (200,200))
            if bf.draw(tela):
                click.play()
                er13 = False
                teladepg = pg14
                
    elif er14 == True:

        if teladepg == pg14:
            tela.blit(erro14, (200,200))
            if bf.draw(tela):
                click.play()
                er14 = False
                teladepg = pg15
                
    elif er15 == True:

        if teladepg == pg15:
            tela.blit(erro15, (200,200))
            if bf.draw(tela):
                click.play()
                er15 = False
                teladepg = pg16

    elif er16 == True:

        if teladepg == pg16:
            tela.blit(erro16, (200,200))
            if bf.draw(tela):
                click.play()
                er16 = False
                teladepg = pg17

    elif er17 == True:

        if teladepg == pg17:
            tela.blit(erro17, (200,200))
            if bf.draw(tela):
                click.play()
                er17 = False
                teladepg = pg18

    elif er18 == True:

        if teladepg == pg18:
            tela.blit(erro18, (200,200))
            if bf.draw(tela):
                click.play()
                er18 = False
                teladepg = pg19

    elif er19 == True:

        if teladepg == pg19:
            tela.blit(erro19, (200,200))
            if bf.draw(tela):
                click.play()
                er19 = False
                teladepg = pg20

    elif er20 == True:

        if teladepg == pg20:
            tela.blit(erro20, (200,200))
            if bf.draw(tela):
                click.play()
                er20 = False
                teladepg = pg21

    elif er21 == True:

        if teladepg == pg21:
            tela.blit(erro21, (200,200))
            if bf.draw(tela):
                click.play()
                er21 = False
                teladepg = pg22

    elif er22 == True:

        if teladepg == pg22:
            tela.blit(erro22, (200,200))
            if bf.draw(tela):
                click.play()
                er22 = False
                teladepg = pg23

    elif er23 == True:

        if teladepg == pg23:
            tela.blit(erro23, (200,200))
            if bf.draw(tela):
                click.play()
                er23 = False
                teladepg = pg24

    elif er24 == True:

        if teladepg == pg24:
            tela.blit(erro24, (200,200))
            if bf.draw(tela):
                click.play()
                er24 = False
                teladepg = pg25

    elif er25 == True:

        if teladepg == pg25:
            tela.blit(erro25, (200,200))
            if bf.draw(tela):
                click.play()
                er25 = False
                teladepg = pg26

    elif er26 == True:

        if teladepg == pg26:
            tela.blit(erro26, (200,200))
            if bf.draw(tela):
                click.play()
                er26 = False
                teladepg = pg27

    elif er27 == True:

        if teladepg == pg27:
            tela.blit(erro27, (200,200))
            if bf.draw(tela):
                click.play()
                er27 = False
                teladepg = pg28

    elif er28 == True:

        if teladepg == pg28:
            tela.blit(erro28, (200,200))
            if bf.draw(tela):
                click.play()
                er28 = False
                teladepg = pg29

    elif er29 == True:

        if teladepg == pg29:
            tela.blit(erro29, (200,200))
            if bf.draw(tela):
                click.play()
                er29 = False
                teladepg = pg30

    elif er30 == True:

        if teladepg == pg30:
            tela.blit(erro30, (200,200))
            if bf.draw(tela):
                click.play()
                er30 = False
                if pontos <= 15:
                    teladepg = tela11
                    er30 = False
                elif pontos > 15 and 30 > pontos:
                    teladepg = tela10
                elif pontos == 30:
                    teladepg = tela9


    if botoes == True:
        if btt1.draw(tela):
            click.play()
            teladepg = manual
            botoes = False

        elif btt2.draw(tela):
            click.play()
            teladepg = tela2
            botoes = False

        elif btt3.draw(tela):
            click.play()
            continua = False

    if teladepg == tela1:
        botoes = True

    for events in pygame.event.get():

        if events.type == pygame.QUIT:
            continua = False

        if teladepg == tela2:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst22 and mouse_y < yst22:
                    click.play()
                    teladepg = tela1

            botoes = False

        if teladepg == manual:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela1

                if mouse_x > xst2 and mouse_y > yst2 and mouse_x < xst22 and mouse_y < yst22:
                    click.play()
                    teladepg = tela3

        elif teladepg == tela3:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = manual

                if mouse_x > xst2 and mouse_y > yst2 and mouse_x < xst22 and mouse_y < yst22:
                    click.play()
                    teladepg = tela4

                if mouse_x > jx1 and mouse_y > jy1 and mouse_x < jx2 and mouse_y < jy2:
                    click.play()
                    abelha = Abelha("Joguinho", 1540, 800)
                    abelha.update()

            botoes = False

        if teladepg == tela4:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela3

                elif mouse_x > xn1 and mouse_y > yn1 and mouse_x < xn12 and mouse_y < yn12:
                    click.play()
                    teladepg = tela6
                    usuario = p12

                elif mouse_x > xn2 and mouse_y > yn2 and mouse_x < xn22 and mouse_y < yn22:
                    click.play()
                    teladepg = tela5
                    usuario = p11

                elif mouse_x > xn3 and mouse_y > yn3 and mouse_x < xn32 and mouse_y < yn32:
                    click.play()
                    teladepg = tela7
                    usuario = p13

                elif mouse_x > xn4 and mouse_y > yn4 and mouse_x < xn42 and mouse_y < yn42:
                    click.play()
                    teladepg = tela8
                    usuario = p14

            botoes = False



        if teladepg == tela5 or teladepg == tela6 or teladepg == tela7 or teladepg == tela8:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela3

                elif mouse_x > xst2 and mouse_y > yst2 and mouse_x < xst22 and mouse_y < yst22:
                    click.play()
                    teladepg = pg1


        if teladepg == pg1:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela3
                    er1 = False
                    pontos = 0

                if mouse_x > txb and mouse_y > tyb and mouse_x < txb2 and mouse_y < tyb2 or mouse_x > uxc and mouse_y > uyc and mouse_x < uxc2 and mouse_y < uyc2 or mouse_x > uxd and mouse_y > uyd and mouse_x < uxd2 and mouse_y < uyd2:
                    erro_sound.play()
                    er1 = True

                    # pag seguinte
                elif mouse_x > uxa and mouse_y > uya and mouse_x < uxa2 and mouse_y < uya2:
                    acerto_sound.play()
                    pontos += 1
                    er1 = False
                    teladepg = pg2


        elif teladepg == pg2:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela3
                    er2 = False
                    pontos = 0

                if mouse_x > dxb and mouse_y > dyb and mouse_x < dxb2 and mouse_y < dyb2 or mouse_x > dxa and mouse_y > dya and mouse_x < dxa2 and mouse_y < dya2 or mouse_x > dxd and mouse_y > dyd and mouse_x < dxd2 and mouse_y < dyd2:
                    erro_sound.play()
                    er2 = True

                # pag seguinte
                elif mouse_x > dxc and mouse_y > dyc and mouse_x < dxc2 and mouse_y < dyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg3
                    pass
                    er2 = False


        elif teladepg == pg3:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er3 = False
                    pontos = 0

                if mouse_x > txa and mouse_y > tya and mouse_x < txa2 and mouse_y < tya2 or mouse_x > txb and mouse_y > tyb and mouse_x < txb2 and mouse_y < tyb2 or mouse_x > txd and mouse_y > tyd and mouse_x < txd2 and mouse_y < tyd2:
                    erro_sound.play()
                    er3 = True

                # pag seguinte
                elif mouse_x > txc and mouse_y > tyc and mouse_x < txc2 and mouse_y < tyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg4
                    pass
                    er3 = False

        elif teladepg == pg4:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er4 = False
                    pontos = 0

                if mouse_x > qxa and mouse_y > qya and mouse_x < qxa2 and mouse_y < qya2 or mouse_x > qxc and mouse_y > qyc and mouse_x < qxc2 and mouse_y < qyc2 or mouse_x > qxd and mouse_y > qyd and mouse_x < qxd2 and mouse_y < qyd2:
                    erro_sound.play()
                    er4 = True

                # pag seguinte
                elif mouse_x > qxb and mouse_y > qyb and mouse_x < qxb2 and mouse_y < qyb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg5
                    pass
                    er4 = False

        elif teladepg == pg5:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er5 = False
                    pontos = 0

                if mouse_x > cxa and mouse_y > cya and mouse_x < cxa2 and mouse_y < cya2 or mouse_x > cxb and mouse_y > cyb and mouse_x < cxb2 and mouse_y < cyb2 or mouse_x > cxd and mouse_y > cyd and mouse_x < cxd2 and mouse_y < cyd2:
                    erro_sound.play()
                    er5 = True

                # pag seguinte
                elif mouse_x > cxc and mouse_y > cyc and mouse_x < cxc2 and mouse_y < cyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg6
                    pass
                    er5 = False

        elif teladepg == pg6:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er6 = False
                    pontos = 0

                if mouse_x > sxa and mouse_y > sya and mouse_x < sxa2 and mouse_y < sya2 or mouse_x > sxc and mouse_y > syc and mouse_x < sxc2 and mouse_y < syc2 or mouse_x > sxd and mouse_y > syd and mouse_x < sxd2 and mouse_y < syd2:
                    erro_sound.play()
                    er6 = True

                # pag seguinte
                elif mouse_x > sxb and mouse_y > syb and mouse_x < sxb2 and mouse_y < syb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg7
                    pass
                    er6 = False

        elif teladepg == pg7:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er7 = False
                    pontos = 0

                if mouse_x > sexb and mouse_y > seyb and mouse_x < sexb2 and mouse_y < seyb2 or mouse_x > sexc and mouse_y > seyc and mouse_x < sexc2 and mouse_y < seyc2 or mouse_x > sexd and mouse_y > seyd and mouse_x < sexd2 and mouse_y < seyd2:
                    erro_sound.play()
                    er7 = True

                # pag seguinte
                elif mouse_x > sexa and mouse_y > seya and mouse_x < sexa2 and mouse_y < seya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg8
                    pass
                    er7 = False

        elif teladepg == pg8:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er8 = False
                    pontos = 0

                if mouse_x > oxa and mouse_y > oya and mouse_x < oxa2 and mouse_y < oya2 or mouse_x > oxc and mouse_y > oyc and mouse_x < oxc2 and mouse_y < oyc2 or mouse_x > oxd and mouse_y > oyd and mouse_x < oxd2 and mouse_y < oyd2:
                    erro_sound.play()
                    er8 = True

                # pag seguinte
                elif mouse_x > oxb and mouse_y > oyb and mouse_x < oxb2 and mouse_y < oyb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg9
                    pass
                    er8 = False

        elif teladepg == pg9:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er9 = False
                    pontos = 0

                if mouse_x > nxa and mouse_y > nya and mouse_x < nxa2 and mouse_y < nya2 or mouse_x > nxc and mouse_y > nyc and mouse_x < nxc2 and mouse_y < nyc2 or mouse_x > nxd and mouse_y > nyd and mouse_x < nxd2 and mouse_y < nyd2:
                    erro_sound.play()
                    er9 = True

                # pag seguinte
                elif mouse_x > nxb and mouse_y > nyb and mouse_x < nxb2 and mouse_y < nyb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg10
                    pass
                    er9 = False

        elif teladepg == pg10:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er10 = False
                    pontos = 0

                if mouse_x > dexa and mouse_y > deya and mouse_x < dexa2 and mouse_y < deya2 or mouse_x > dexb and mouse_y > deyb and mouse_x < dexb2 and mouse_y < deyb2 or mouse_x > dexd and mouse_y > deyd and mouse_x < dexd2 and mouse_y < deyd2:
                    erro_sound.play()
                    er10 = True

                # pag seguinte
                elif mouse_x > dexc and mouse_y > deyc and mouse_x < dexc2 and mouse_y < deyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg11
                    pass
                    er10 = False

        elif teladepg == pg11:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er11 = False
                    pontos = 0

                if mouse_x > onxa and mouse_y > onya and mouse_x < onxa2 and mouse_y < onya2 or mouse_x > onxc and mouse_y > onyc and mouse_x < onxc2 and mouse_y < onyc2 or mouse_x > onxb and mouse_y > onyb and mouse_x < onxb2 and mouse_y < onyb2:
                    erro_sound.play()
                    er11 = True

                # pag seguinte
                elif mouse_x > onxd and mouse_y > onyd and mouse_x < onxd2 and mouse_y < onyd2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg12
                    pass
                    er11 = False

        elif teladepg == pg12:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er12 = False
                    pontos = 0

                if mouse_x > dozxa and mouse_y > dozya and mouse_x < dozxa2 and mouse_y < dozya2 or mouse_x > dozxb and mouse_y > dozyb and mouse_x < dozxb2 and mouse_y < dozyb2 or mouse_x > dozxd and mouse_y > dozyd and mouse_x < dozxd2 and mouse_y < dozyd2:
                    erro_sound.play()
                    er12 = True

                # pag seguinte
                elif mouse_x > dozxc and mouse_y > dozyc and mouse_x < dozxc2 and mouse_y < dozyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg13
                    pass
                    er12 = False


        elif teladepg == pg13:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er13 = False
                    pontos = 0

                if mouse_x > trxa and mouse_y > trya and mouse_x < trxa2 and mouse_y < trya2 or mouse_x > trxc and mouse_y > tryc and mouse_x < trxc2 and mouse_y < tryc2:
                    erro_sound.play()
                    er13 = True

                # pag seguinte
                elif mouse_x > trxb and mouse_y > tryb and mouse_x < trxb2 and mouse_y < tryb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg14
                    pass
                    er13 = False

        elif teladepg == pg14:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er14 = False
                    pontos = 0

                if mouse_x > quatxa and mouse_y > quatya and mouse_x < quatxa2 and mouse_y < quatya2 or mouse_x > quatxb and mouse_y > quatyb and mouse_x < quatxb2 and mouse_y < quatyb2:
                    erro_sound.play()
                    er14 = True

                # pag seguinte
                elif mouse_x > quatxc and mouse_y > quatyc and mouse_x < quatxc2 and mouse_y < quatyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg15
                    pass
                    er14 = False

        elif teladepg == pg15:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er15 = False
                    pontos = 0

                if mouse_x > quinxa and mouse_y > quinya and mouse_x < quinxa2 and mouse_y < quinya2 or mouse_x > quinxb and mouse_y > quinyb and mouse_x < quinxb2 and mouse_y < quinyb2 or mouse_x > quinxd and mouse_y > quinyd and mouse_x < quinxd2 and mouse_y < quinyd2:
                    erro_sound.play()
                    er15 = True

                # pag seguinte
                elif mouse_x > quinxc and mouse_y > quinyc and mouse_x < quinxc2 and mouse_y < quinyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg16
                    pass
                    er15 = False

        elif teladepg == pg16:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er16 = False
                    pontos = 0

                if mouse_x > dezxc and mouse_y > dezyc and mouse_x < dezxc2 and mouse_y < dezyc2 or mouse_x > quinxb and mouse_y > quinyb and mouse_x < quinxb2 and mouse_y < quinyb2 or mouse_x > quinxd and mouse_y > quinyd and mouse_x < quinxd2 and mouse_y < quinyd2:
                    erro_sound.play()
                    er16 = True

                # pag seguinte
                elif mouse_x > dezxa and mouse_y > dezya and mouse_x < dezxa2 and mouse_y < dezya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg17
                    pass
                    er16 = False

        elif teladepg == pg17:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er17 = False
                    pontos = 0

                if mouse_x > dezexa and mouse_y > dezeya and mouse_x < dezexa2 and mouse_y < dezeya2 or mouse_x > dezexb and mouse_y > dezeyb and mouse_x < dezexb2 and mouse_y < dezeyb2 or mouse_x > dezexc and mouse_y > dezeyc and mouse_x < dezexc2 and mouse_y < dezeyc2:
                    erro_sound.play()
                    er17 = True

                # pag seguinte
                elif mouse_x > dezexd and mouse_y > dezeyd and mouse_x < dezexd2 and mouse_y < dezeyd2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg18
                    pass
                    er17 = False

        elif teladepg == pg18:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er18 = False
                    pontos = 0

                if mouse_x > dezoxa and mouse_y > dezoya and mouse_x < dezoxa2 and mouse_y < dezoya2 or mouse_x > dezoxb and mouse_y > dezoyb and mouse_x < dezoxb2 and mouse_y < quinyb2 or mouse_x > dezoxd and mouse_y > dezoyd and mouse_x < dezoxd2 and mouse_y < dezoyd2:
                    erro_sound.play()
                    er18 = True

                # pag seguinte
                elif mouse_x > dezoxc and mouse_y > dezoyc and mouse_x < dezoxc2 and mouse_y < dezoyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg19
                    pass
                    er18 = False

        elif teladepg == pg19:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er19 = False
                    pontos = 0

                if mouse_x > dezenxa and mouse_y > dezenya and mouse_x < dezenxa2 and mouse_y < dezenya2 or mouse_x > dezenxb and mouse_y > dezenyb and mouse_x < dezenxb2 and mouse_y < dezenyb2 or mouse_x > dezenxd and mouse_y > dezenyd and mouse_x < dezenxd2 and mouse_y < dezenyd2:
                    erro_sound.play()
                    er19 = True

                # pag seguinte
                elif mouse_x > dezenxc and mouse_y > dezenyc and mouse_x < dezenxc2 and mouse_y < dezenyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg20
                    pass
                    er19 = False

        elif teladepg == pg20:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er20 = False
                    pontos = 0

                if mouse_x > vxa and mouse_y > vya and mouse_x < vxa2 and mouse_y < vya2 or mouse_x > vxc and mouse_y > vyc and mouse_x < vxc2 and mouse_y < vyc2 or mouse_x > vxd and mouse_y > vyd and mouse_x < vxd2 and mouse_y < vyd2:
                    erro_sound.play()
                    er20 = True

                # pag seguinte
                elif mouse_x > vxb and mouse_y > vyb and mouse_x < vxb2 and mouse_y < vyb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg21
                    pass
                    er20 = False

        elif teladepg == pg21:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er21 = False
                    pontos = 0

                if mouse_x > vuxa and mouse_y > vuya and mouse_x < vuxa2 and mouse_y < vuya2 or mouse_x > vuxb and mouse_y > vuyb and mouse_x < vuxb2 and mouse_y < vuyb2 or mouse_x > vuxd and mouse_y > vuyd and mouse_x < vuxd2 and mouse_y < quinyd2:
                    erro_sound.play()
                    er21 = True

                # pag seguinte
                elif mouse_x > vuxc and mouse_y > vuyc and mouse_x < vuxc2 and mouse_y < vuyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg22
                    pass
                    er21 = False

        elif teladepg == pg22:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er22 = False
                    pontos = 0

                if mouse_x > vdxc and mouse_y > vdyc and mouse_x < vdxc2 and mouse_y < vdyc2 or mouse_x > vdxb and mouse_y > vdyb and mouse_x < vdxb2 and mouse_y < vdyb2 or mouse_x > quinxd and mouse_y > vdyd and mouse_x < vdxd2 and mouse_y < vdyd2:
                    erro_sound.play()
                    er22 = True

                # pag seguinte
                elif mouse_x > vdxa and mouse_y > vdya and mouse_x < vdxa2 and mouse_y < vdya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg23
                    pass
                    er22 = False

        elif teladepg == pg23:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er23 = False
                    pontos = 0

                if mouse_x > vtxa and mouse_y > vtya and mouse_x < vtxa2 and mouse_y < vtya2 or mouse_x > vtxc and mouse_y > vtyc and mouse_x < vtxc2 and mouse_y < vtyc2 or mouse_x > vtxd and mouse_y > vtyd and mouse_x < vtxd2 and mouse_y < vtyd2:
                    erro_sound.play()
                    er23 = True

                # pag seguinte
                elif mouse_x > vtxb and mouse_y > vtyb and mouse_x < vtxb2 and mouse_y < vtyb2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg24
                    pass
                    er23 = False

        elif teladepg == pg24:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er24 = False
                    pontos = 0

                if mouse_x > vqxc and mouse_y > vqyc and mouse_x < vqxc2 and mouse_y < vqyc2 or mouse_x > vqxb and mouse_y > vqyb and mouse_x < vqxb2 and mouse_y < vqyb2 or mouse_x > vqxd and mouse_y > vqyd and mouse_x < vqxd2 and mouse_y < vqyd2:
                    erro_sound.play()
                    er24 = True

                # pag seguinte
                elif mouse_x > vqxa and mouse_y > vqya and mouse_x < vqxa2 and mouse_y < vqya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg25
                    pass
                    er24 = False

        elif teladepg == pg25:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er25 = False
                    pontos = 0

                if mouse_x > vcxc and mouse_y > vcyc and mouse_x < vcxc2 and mouse_y < vcyc2 or mouse_x > vcxb and mouse_y > vcyb and mouse_x < vcxb2 and mouse_y < vcyb2 or mouse_x > vcxa and mouse_y > vcya and mouse_x < vcxa2 and mouse_y < vcya2:
                    erro_sound.play()
                    er25 = True

                # pag seguinte
                elif mouse_x > vcxd and mouse_y > vcyd and mouse_x < vcxd2 and mouse_y < vcyd2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg26
                    pass
                    er25 = False

        elif teladepg == pg26:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er26 = False
                    pontos = 0

                if mouse_x > vsxc and mouse_y > vsyc and mouse_x < vsxc2 and mouse_y < vsyc2 or mouse_x > vsxb and mouse_y > vsyb and mouse_x < vsxb2 and mouse_y < vsyb2 or mouse_x > vsxd and mouse_y > vsyd and mouse_x < vsxd2 and mouse_y < vsyd2:
                    erro_sound.play()
                    er26 = True

                # pag seguinte
                elif mouse_x > vsxa and mouse_y > vsya and mouse_x < vsxa2 and mouse_y < vsya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg27
                    pass
                    er26 = False

        elif teladepg == pg27:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er27 = False

                if mouse_x > vsexa and mouse_y > vseya and mouse_x < vsexa2 and mouse_y < vseya2 or mouse_x > vsexb and mouse_y > vseyb and mouse_x < vsexb2 and mouse_y < vseyb2 or mouse_x > vsexd and mouse_y > vseyd and mouse_x < vsexd2 and mouse_y < vseyd2:
                    erro_sound.play()
                    er27 = True

                # pag seguinte
                elif mouse_x > vsexc and mouse_y > vseyc and mouse_x < vsexc2 and mouse_y < vseyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg28
                    pass
                    er27 = False

        elif teladepg == pg28:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er28 = False

                if mouse_x > voxc and mouse_y > voyc and mouse_x < voxc2 and mouse_y < voyc2 or mouse_x > voxb and mouse_y > voyb and mouse_x < voxb2 and mouse_y < voyb2 or mouse_x > voxd and mouse_y > voyd and mouse_x < voxd2 and mouse_y < voyd2:
                    erro_sound.play()
                    er28 = True

                # pag seguinte
                elif mouse_x > voxa and mouse_y > voya and mouse_x < voxa2 and mouse_y < voya2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg29
                    pass
                    er28 = False

        elif teladepg == pg29:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er29 = False

                if mouse_x > vnxa and mouse_y > vnya and mouse_x < vnxa2 and mouse_y < vnya2 or mouse_x > vnxb and mouse_y > vnyb and mouse_x < vnxb2 and mouse_y < vnyb2 or mouse_x > vnxd and mouse_y > vnyd and mouse_x < vnxd2 and mouse_y < vnyd2:
                    erro_sound.play()
                    er29 = True

                # pag seguinte
                elif mouse_x > vnxc and mouse_y > vnyc and mouse_x < vnxc2 and mouse_y < vnyc2:
                    acerto_sound.play()
                    pontos += 1
                    teladepg = pg30
                    pass
                    er29 = False

        elif teladepg == pg30:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > xst1 and mouse_y > yst1 and mouse_x < xst12 and mouse_y < yst12:
                    click.play()
                    teladepg = tela4
                    er30 = False

                if mouse_x > trixa and mouse_y > triya and mouse_x < vnxa2 and mouse_y < triya2 or mouse_x > trixc and mouse_y > triyc and mouse_x < trixc2 and mouse_y < triyc2 or mouse_x > trixd and mouse_y > triyd and mouse_x < trixd2 and mouse_y < triyd2:
                    erro_sound.play()
                    er30 = True

                # pag seguinte
                elif mouse_x > trixb and mouse_y > triyb and mouse_x < trixb2 and mouse_y < triyb2:
                    acerto_sound.play()
                    pontos += 1
                    if pontos <= 15:
                        teladepg = tela11
                        er30 = False
                    elif pontos > 15 and 30 > pontos:
                        teladepg = tela10
                    elif pontos == 30:
                        teladepg = tela9

        elif teladepg == tela11:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > x1fn1 and mouse_y > y1fn1 and mouse_x < x2fn1 and mouse_y < y2fn1:
                    click.play()
                    teladepg = tela12

                if mouse_x > x1fn2 and mouse_y > y1fn2 and mouse_x < x2fn2 and mouse_y < y2fn2:
                    click.play()
                    teladepg = tela1
                    pontos = 0

        elif teladepg == tela10:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > x1fn1 and mouse_y > y1fn1 and mouse_x < x2fn1 and mouse_y < y2fn1:
                    click.play()
                    teladepg = tela12

                if mouse_x > x1fn2 and mouse_y > y1fn2 and mouse_x < x2fn2 and mouse_y < y2fn2:
                    click.play()
                    teladepg = tela1
                    pontos = 0

        elif teladepg == tela9:

            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]

                if mouse_x > x1fn1 and mouse_y > y1fn1 and mouse_x < x2fn1 and mouse_y < y2fn1:
                    click.play()
                    teladepg = tela12

                if mouse_x > x1fn2 and mouse_y > y1fn2 and mouse_x < x2fn2 and mouse_y < y2fn2:
                    click.play()
                    teladepg = tela1
                    pontos = 0

        elif teladepg == tela12:
            if events.type == MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()[0]
                mouse_y = pygame.mouse.get_pos()[1]
                if mouse_x > xst2 and mouse_y > yst2 and mouse_x < xst22 and mouse_y < yst22:
                    click.play()
                    teladepg = tela1
                    pontos = 0





    if teladepg == tela4:

        sprites.draw(tela)
        sprites.update()

    if teladepg == tela5 or teladepg == tela6 or teladepg == tela7 or teladepg == tela8:

        usuario.draw(tela)
        usuario.update()

    if teladepg == pg1 or teladepg == pg2 or teladepg == pg3 or teladepg == pg4 or teladepg == pg5 or teladepg == pg6 or teladepg == pg7 or teladepg == pg8 or teladepg == pg9 or teladepg == pg10 or teladepg == pg11 or teladepg == pg12 or teladepg == pg13 or teladepg == pg14 or teladepg == pg15 or teladepg == pg16 or teladepg == pg17 or teladepg == pg18 or teladepg == pg19 or teladepg == pg20 or teladepg == pg21 or teladepg == pg22 or teladepg == pg23 or teladepg == pg24 or teladepg == pg25 or teladepg == pg26 or teladepg == pg27 or teladepg == pg28 or teladepg == pg29 or teladepg == pg30 or teladepg == tela9 or teladepg == tela10 or teladepg == tela11:
        tela.blit(texto, (1300, 122))
        if usuario == p11:
            usuario = c11
        if usuario == p12:
            usuario = c12
        if usuario == p13:
            usuario = c13
        if usuario == p14:
            usuario = c14

        usuario.draw(tela)
        usuario.update()



    pygame.display.flip()